import './App.css';
import SignInSide from './components/login/Login';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ButtonAppBar from './components/header/Header';
import Halls from './components/halls/Halls'
import Home from './components/home/Home';

function App() {
  return (
    <Router>
      <ButtonAppBar />
      <main className="App">
        <Routes>
          
          <Route path="/" element={<SignInSide />}></Route>
          <Route path="/halls" element={<Halls />}></Route>
          <Route path="/home" element={<Home />}></Route>
        </Routes>
      </main>
    </Router>
    

  );
}

export default App;
