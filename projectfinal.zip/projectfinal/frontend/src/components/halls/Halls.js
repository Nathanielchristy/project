import React, { useEffect } from 'react';
import axios from 'axios'



const fetch= async() =>{
    const data=await axios.get('/');
    console.log(data)
}



function Halls(props) {
    useEffect(() =>{
        fetch();
    },[])
    return (
        <div>
            
        </div>
    );
}

export default Halls;